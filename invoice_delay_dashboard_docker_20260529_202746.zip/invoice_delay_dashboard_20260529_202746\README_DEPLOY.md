# Invoice Delay Risk Analytics Dashboard

저장된 최종 Stacking 모델을 사용해 인보이스 연체 확률을 실시간으로 예측하는 Streamlit 대시보드입니다.

## 권장 실행 방식: Docker

다른 PC에서 가장 안정적인 방식은 Docker 실행입니다. Python 버전과 `scikit-learn`, `xgboost`, `lightgbm` 같은 네이티브 패키지 환경을 컨테이너 안에 고정합니다.

1. Docker Desktop을 설치하고 실행합니다.
2. 이 폴더에서 `run_docker.bat`을 실행합니다.
3. 브라우저에서 `http://localhost:8501`로 접속합니다.

수동 Docker 실행:

```powershell
docker build -t invoice-delay-dashboard .
docker run --rm -p 8501:8501 invoice-delay-dashboard
```

## 대체 실행 방식: 로컬 Python

Docker를 사용할 수 없는 경우 `run_dashboard.bat`을 실행합니다. 이 방식은 실행 PC의 Python 설치 상태와 네트워크 환경에 영향을 받을 수 있습니다.

수동 실행:

```powershell
python -m venv .venv
.\.venv\Scripts\activate
python -m pip install -r requirements.txt
streamlit run app.py
```

## 포함 파일

- `app.py`: Streamlit 대시보드 화면
- `src/invoice_delay_service.py`: 모델 로딩, 입력 변환, 예측 로직
- `src/__init__.py`: Python 패키지 초기화 파일
- `models/invoice_delay_stacking.joblib`: 최종 학습 모델 artifact
- `requirements.txt`: 실행에 필요한 Python 패키지
- `Dockerfile`: 컨테이너 실행 환경 정의
- `.dockerignore`: Docker 빌드 제외 파일 목록
- `run_docker.bat`: Docker 실행 스크립트
- `run_dashboard.bat`: 로컬 Python 실행 스크립트

## 주의 사항

- `models/invoice_delay_stacking.joblib` 파일을 삭제하거나 위치를 바꾸면 대시보드가 모델을 불러오지 못합니다.
- Docker 방식도 최초 실행 시 이미지를 만들면서 패키지를 다운로드합니다. 한 번 빌드한 뒤에는 같은 PC에서 재사용됩니다.
- 이 배포본은 예측 전용입니다. 모델 재학습 화면과 학습 데이터는 포함하지 않습니다.
