@echo off
setlocal
cd /d "%~dp0"

where docker >nul 2>nul
if errorlevel 1 (
    echo Docker Desktop is required. Install and start Docker Desktop, then run this file again.
    pause
    exit /b 1
)

docker build -t invoice-delay-dashboard .
if errorlevel 1 (
    echo Docker image build failed.
    pause
    exit /b 1
)

docker run --rm -p 8501:8501 invoice-delay-dashboard
